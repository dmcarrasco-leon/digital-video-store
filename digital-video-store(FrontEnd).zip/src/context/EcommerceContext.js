import { createContext } from "react";

const ecommerceContext = createContext();

export default ecommerceContext;